import { configure as serverlessExpress } from '@vendia/serverless-express';
import { NestFactory } from "@nestjs/core";
import { AppModule } from "./src/app.module";

let cachedServer: any;

export const handler = async (event: any, context: any) => {
  if (!cachedServer) {
    const nestApp = await NestFactory.create(AppModule);
    nestApp.enableCors();
    await nestApp.init();
    cachedServer = serverlessExpress({ app: nestApp.getHttpAdapter().getInstance() });
  }
  return cachedServer(event, context);
}

// import { ValidationPipe } from '@nestjs/common';
// import { NestFactory } from '@nestjs/core';
// import serverlessExpress from '@vendia/serverless-express';
// import { Callback, Context, Handler } from 'aws-lambda';

// import { AppModule } from './src/app.module';

// let server: Handler;

// async function bootstrap() {
//   const app = await NestFactory.create(AppModule);
//   // here do what you need
//   await app.init();

//   const expressApp = app.getHttpAdapter().getInstance();
//   return serverlessExpress({ app: expressApp });
// }

// export const handler: Handler = async (
//   event: any,
//   context: Context,
//   callback: Callback,
// ) => {
//   server = server ?? (await bootstrap());

//   try {
//     const result = await server(event, context, callback);
//     // Ensure the response from the server is in the proper format
//     if (typeof result === 'object' && 'statusCode' in result) {
//       // Set CORS headers
//       result.headers = {
//         ...result.headers,
//         'Access-Control-Allow-Origin': '*', // Allow all origins
//         'Access-Control-Allow-Credentials': true,
//         'Access-Control-Allow-Headers': 'Content-Type', // Allow specific headers
//       };
//     }

//     return result;
//   } catch (error) {
//     // Handle any errors that occur during execution
//     console.error('Error:', error);
//     return {
//       statusCode: 500,
//       headers: {
//         'Access-Control-Allow-Origin': '*', // Allow all origins
//         'Access-Control-Allow-Credentials': true,
//       },
//       body: JSON.stringify({
//         message: 'Internal Server Error',
//       }),
//     };
//   }
// };