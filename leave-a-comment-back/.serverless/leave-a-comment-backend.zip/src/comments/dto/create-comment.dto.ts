export class CreateCommentDto {
  site: string;
  name: string;
  body: string;
}
