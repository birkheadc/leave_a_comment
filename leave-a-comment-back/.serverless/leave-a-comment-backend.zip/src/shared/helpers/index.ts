import { fetchSecretKey } from "./fetchSecretKey";

export default {  
  fetchSecretKey
}